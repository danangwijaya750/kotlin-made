package com.dngwjy.madesub3.presentation.ui.detail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.dngwjy.madesub3.R
import com.dngwjy.madesub3.presentation.model.MovieModel
import com.dngwjy.madesub3.presentation.model.TvModel
import com.dngwjy.madesub3.util.Helper
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        setData()
    }

    private fun  setData(){
        when(intent.getStringExtra(Helper.STATE_INTENT)){
            "movie"->{
                val dataSended: MovieModel=intent.getParcelableExtra(Helper.MOVIE_PARCEL)
                Glide.with(this).load("${Helper.BASE_IMAGE_URL}${dataSended.posterPath}")
                    .into(image_detail_movie)
                tv_detail_title_movie.text=dataSended.title
                tv_detail_overview.text=dataSended.overview
                tv_detail_rating.text=dataSended.voteAverage.toString()
                tv_detail_runtime.text=dataSended.voteCount.toString()
                tv_detail_language.text=dataSended.popularity.toString()
                tv_detail_release.text=dataSended.releaseDate


            }
            "tv"->{
                val dataSended: TvModel=intent.getParcelableExtra(Helper.TV_PARCEL)
                Glide.with(this).load("${Helper.BASE_IMAGE_URL}${dataSended.posterPath}")
                    .into(image_detail_movie)
                tv_detail_title_movie.text=dataSended.name
                tv_detail_overview.text=dataSended.overview
                tv_detail_rating.text=dataSended.voteAverage.toString()
                tv_detail_runtime.text=dataSended.voteCount.toString()
                tv_detail_language.text=dataSended.popularity.toString()
                tv_detail_release.text=dataSended.firstAirDate


            }
        }
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.option_menu,menu)
        return  super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if (item?.getItemId() === R.id.action_change_settings) {
            val mIntent = Intent(Settings.ACTION_LOCALE_SETTINGS)
            startActivity(mIntent)
        }
        return super.onOptionsItemSelected(item)
    }
}
