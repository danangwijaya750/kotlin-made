package com.dngwjy.madesub3.di

import com.dngwjy.madesub3.presentation.ui.main.movie_fragment.MovieViewModel
import com.dngwjy.madesub3.presentation.ui.main.tv_fragment.TvViewModel
import org.koin.dsl.module.module

/**
 * Created by wijaya on 25/06/19
 */
val vmModule= module {
    single {
         MovieViewModel(get())
    }
    single {
        TvViewModel(get())
    }
}