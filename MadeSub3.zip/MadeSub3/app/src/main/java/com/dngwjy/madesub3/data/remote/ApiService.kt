package com.dngwjy.madesub3.data.remote

import com.dngwjy.madesub3.data.remote.model.MovieResponse
import com.dngwjy.madesub3.data.remote.model.TvResponse
import com.dngwjy.madesub3.util.Helper
import io.reactivex.Observable
import retrofit2.http.GET


/**
 * Created by wijaya on 25/06/19
 */
interface ApiService {
    @GET("movie?sort_by=popularity.desc&api_key=${Helper.API_KEY}&language=en-US")
    fun getMovies(): Observable<MovieResponse>

    @GET("tv?sort_by=popularity.desc&api_key=${Helper.API_KEY}&language=en-US")
    fun getTVs():Observable<TvResponse>
}