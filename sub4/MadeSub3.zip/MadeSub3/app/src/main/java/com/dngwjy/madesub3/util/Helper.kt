package com.dngwjy.madesub3.util

/**
 * Created by wijaya on 26/06/19
 */
object Helper {
    const val BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w780"
    const val BASE_URL_API = "https://api.themoviedb.org/3/discover/"
    const val API_KEY = "75afbeac6103b3207a6e977639450db4"
    const val TV_PARCEL = "datamovie"
    const val MOVIE_PARCEL = "datatv"
    const val STATE_INTENT = "state"
}